# CampusLink SRS (LaTeX source)

Compile with **XeLaTeX** (not pdfLaTeX), twice, for the table of contents:

    xelatex main.tex && xelatex main.tex

Overleaf: Menu > Compiler > **XeLaTeX**, main document `main.tex`.

- `main.tex`, `preamble.tex`: document and styling
- `tex/`: figures drawn in TikZ and the requirement tables
- `gv/`: ER, DFD and state diagrams (PDF)
- `src/fig/`: UI screenshots
- `fonts/`: Inter (SIL OFL), loaded by path so no system install is needed

- `figs/`: TikZ diagrams and the cover, pre-rendered to PDF so the free Overleaf plan compiles within its time limit (about 2 s locally). Sources are `figs/*.tex` and `tex/fig_*.tex`.
